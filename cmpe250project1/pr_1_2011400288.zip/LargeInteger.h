#ifndef _LARGEINTEGER_H
#define _LARGEINTEGER_H

#include <deque>
#include <iostream>

class LargeInteger{
private:
    std::deque<int> digits;

public:
    LargeInteger(int n);
    LargeInteger();
    ~LargeInteger();

    LargeInteger& operator +=(const LargeInteger &o);
    LargeInteger& operator *(const LargeInteger &o);
    friend std::ostream& operator << (std::ostream& out, const LargeInteger& n);
};

#endif
