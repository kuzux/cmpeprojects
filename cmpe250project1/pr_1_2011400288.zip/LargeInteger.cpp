/*
Student Name: Arda Cinar
Student Number: 2011400288
Project Numbner: 1
Operating System: Linux (Ubuntu 12.04, gcc 4.6.3)
Compile Status: Compiling
Program Status: Working
Notes: The program takes about 15 seconds to complete for N=200.
*/

#include "LargeInteger.h"
#include <math.h>
using namespace std;

#define BASE 10

// The LargeInteger class holds the value as a vector of digits, in base 10
// Using a larger base (as large as a normal integer can hold) could have been more efficient
// but just using base 10 is fast enough for this case, and much easier to deal with.
// Also, the digits are stored from right-to-left.
LargeInteger::LargeInteger(int n){
    do{
        digits.push_back(n%BASE);
        n/=BASE;
    }while(n>0);
}

LargeInteger::LargeInteger(){
}

LargeInteger::~LargeInteger(){ }

// In-place addition
// Uses an elementary method, starts from the smallest figure and starts adding up the digits
// If a carry digit is left at the end, adds it to the result.

LargeInteger& LargeInteger::operator +=(const LargeInteger& o){
    int i;
    int carry=0;
    for(i=0;i<o.digits.size();i++){

        if(i<digits.size()){
            // perform the addition and determine the carry and digit values
            int sum = o.digits[i]+digits[i]+carry;
            carry = sum/BASE;
            sum %= BASE;

            digits[i]=sum;
        } else {
            // If we have run out of digits in the digits deque

            int sum = o.digits[i]+carry;
            carry = sum/BASE;
            sum %= BASE;
            digits.push_back(sum);
        }
    }

    // a carry digit might be left at the end.
    // add it to the number
    while(carry){
        if(i<digits.size()){
            digits[i]++;
            carry = digits[i]/BASE;
            digits[i]%=BASE;
            i++;
        }else{
            digits.push_back(carry);
            carry = 0;
        }
    }

    return *this;
}

LargeInteger& LargeInteger::operator *(const LargeInteger& o){
    LargeInteger* res = new LargeInteger();


    for(int i=0;i<o.digits.size();i++){
        // for each digit in b
        // we'll need to shift the result by i 0s
        LargeInteger tmp;
        int carry = 0;
        for(int j=0;j<digits.size();j++){
            // for each digit in a.
            // calculate the current digit's result and the carry value
            int prod = digits[j]*o.digits[i]+carry;
            carry = prod/BASE;
            
            tmp.digits.push_back(prod%BASE);
        }
        if(carry) tmp.digits.push_back(carry);

        // adding the zeros
        for(int j=0;j<i;j++)
            tmp.digits.push_front(0);

        (*res) += tmp;
    }

    return *res;
}

// Since the large integers are represented smallest-digit first, iterates back to print out the number.
ostream& operator << (ostream& out, const LargeInteger& n){
    for(int i=n.digits.size()-1;i>=0;i--){
        out << n.digits[i];
    }
    return out;
}

int main(){
    // Store intermediate results in an array to make the program much more efficient
    // for all i, only values smaller than i are needed, so we can write the 
    // procedure for calculating Catalan Numbers iteratively
    LargeInteger T[201];

    T[0] = LargeInteger(1);
    cout << 0 << " " << T[0] << endl;
    for(int i=1; i<201;i++){
        T[i] = LargeInteger(0);
        for(int j=0;j<i;j++){
            T[i] += T[j]*T[i-j-1];
        }
        cout << i << " " << T[i] << endl; 
    }
}
